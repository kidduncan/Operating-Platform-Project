package com.gamingroom;

/**
 * Application start-up program used to test the game application.
 */
public class ProgramDriver {

    /**
     * Main method used to test games, teams, players, duplicate names,
     * and the Singleton pattern.
     *
     * @param args command-line arguments
     */
    public static void main(String[] args) {

        // Obtain the single shared GameService instance.
        GameService service = GameService.getInstance();

        System.out.println("About to test initializing game data...");

        // Add two games.
        Game game1 = service.addGame("Game #1");
        Game game2 = service.addGame("Game #2");

        System.out.println(game1);
        System.out.println(game2);

        // Test duplicate game name.
        Game duplicateGame = service.addGame("Game #1");
        System.out.println("Duplicate game check: " + duplicateGame);

        // Add teams to the first game.
        Team team1 = game1.addTeam("Team Alpha");
        Team team2 = game1.addTeam("Team Beta");

        System.out.println(team1);
        System.out.println(team2);

        // Test duplicate team name.
        Team duplicateTeam = game1.addTeam("Team Alpha");
        System.out.println("Duplicate team check: " + duplicateTeam);

        // Add players to Team Alpha.
        Player player1 = team1.addPlayer("Player One");
        Player player2 = team1.addPlayer("Player Two");

        System.out.println(player1);
        System.out.println(player2);

        // Test duplicate player name.
        Player duplicatePlayer = team1.addPlayer("Player One");
        System.out.println("Duplicate player check: " + duplicatePlayer);

        // Test that another class receives the same GameService instance.
        SingletonTester tester = new SingletonTester();
        tester.testSingleton();
    }
}