package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Represents a team participating in a game.
 * Each team has a unique identifier, a unique name, and multiple players.
 */
public class Team extends Entity {

    /**
     * Stores the players assigned to this team.
     */
    private List<Player> players = new ArrayList<Player>();

    /**
     * Constructor.
     *
     * @param id unique team identifier
     * @param name unique team name
     */
    public Team(long id, String name) {
        super(id, name);
    }

    /**
     * Adds a player to the team if the player's name is not already in use.
     *
     * The iterator pattern searches each existing player one at a time.
     * If a matching name is found, the existing player is returned instead
     * of creating a duplicate.
     *
     * @param playerId unique player identifier
     * @param playerName unique player name
     * @return the existing or newly created player
     */
    /**
     * Adds a player if the supplied player name is not already being used.
     *
     * The Iterator pattern searches through the current players one at a time.
     * If a matching name is found, the existing player is returned instead of
     * creating a duplicate.
     *
     * @param name unique player name
     * @return existing or newly created player
     */
    public Player addPlayer(String name) {

        Player player = null;

        Iterator<Player> playerIterator = players.iterator();

        while (playerIterator.hasNext()) {
            Player currentPlayer = playerIterator.next();

            if (currentPlayer.getName().equals(name)) {
                player = currentPlayer;
                break;
            }
        }

        if (player == null) {
            player = new Player(GameService.getNextPlayerId(), name);
            players.add(player);
        }

        return player;
    }

    /**
     * Returns the player at the specified list position.
     *
     * @param index player list index
     * @return player at the selected index
     */
    public Player getPlayer(int index) {
        return players.get(index);
    }

    /**
     * Returns the number of players assigned to the team.
     *
     * @return number of players
     */
    public int getPlayerCount() {
        return players.size();
    }

    /**
     * Returns a formatted description of the team.
     */
    @Override
    public String toString() {
        return "Team [id=" + id + ", name=" + name + "]";
    }
}