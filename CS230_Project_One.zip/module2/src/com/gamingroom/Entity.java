package com.gamingroom;

/**
 * A base class that represents common attributes shared by all entities
 * in the game application.
 */
public class Entity {

    /**
     * A unique identifier.
     */
    protected long id;

    /**
     * A unique name.
     */
    protected String name;

    /**
     * Constructor.
     *
     * @param id unique identifier
     * @param name unique name
     */
    public Entity(long id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     * Returns the unique identifier.
     *
     * @return entity id
     */
    public long getId() {
        return id;
    }

    /**
     * Returns the entity name.
     *
     * @return entity name
     */
    public String getName() {
        return name;
    }

    /**
     * Returns a string representation of the entity.
     */
    @Override
    public String toString() {
        return "Entity [id=" + id + ", name=" + name + "]";
    }
}