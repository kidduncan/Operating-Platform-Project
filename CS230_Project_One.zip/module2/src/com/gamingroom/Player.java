package com.gamingroom;

/**
 * Represents a player assigned to a team.
 * A player inherits the common identifier and name fields from Entity.
 */
public class Player extends Entity {

    /**
     * Constructor.
     *
     * @param id unique player identifier
     * @param name unique player name
     */
    public Player(long id, String name) {
        super(id, name);
    }

    /**
     * Returns a formatted description of the player.
     */
    @Override
    public String toString() {
        return "Player [id=" + id + ", name=" + name + "]";
    }
}