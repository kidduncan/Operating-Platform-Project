package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Provides services for creating and locating games.
 *
 * The Singleton pattern ensures that only one GameService instance exists
 * in memory. The private constructor prevents outside classes from creating
 * additional instances, and getInstance() provides access to the shared
 * service object.
 */
public class GameService {

    /**
     * Stores all games currently managed by the application.
     */
    private static List<Game> games = new ArrayList<Game>();

    /**
     * Identifiers assigned to new games, teams, and players.
     */
    private static long nextGameId = 1;
    private static long nextTeamId = 1;
    private static long nextPlayerId = 1;

    /**
     * The one shared GameService instance.
     */
    private static final GameService instance = new GameService();

    /**
     * Private constructor prevents other classes from creating another
     * GameService object.
     */
    private GameService() {
    }

    /**
     * Returns the shared GameService instance.
     *
     * @return singleton GameService instance
     */
    public static GameService getInstance() {
        return instance;
    }

    /**
     * Returns the next available team identifier and then increments it.
     *
     * @return unique team identifier
     */
    public static long getNextTeamId() {
        return nextTeamId++;
    }

    /**
     * Returns the next available player identifier and then increments it.
     *
     * @return unique player identifier
     */
    public static long getNextPlayerId() {
        return nextPlayerId++;
    }

    /**
     * Adds a game if its name is not already in use.
     *
     * The Iterator pattern examines each existing game without exposing
     * the internal implementation of the collection. If a matching game
     * name is found, the existing game is returned.
     *
     * @param name requested game name
     * @return existing or newly created game
     */
    public Game addGame(String name) {

        Game game = null;

        Iterator<Game> gameIterator = games.iterator();

        while (gameIterator.hasNext()) {
            Game currentGame = gameIterator.next();

            if (currentGame.getName().equals(name)) {
                game = currentGame;
                break;
            }
        }

        if (game == null) {
            game = new Game(nextGameId++, name);
            games.add(game);
        }

        return game;
    }

    /**
     * Returns the game at the specified list position.
     *
     * @param index position in the game list
     * @return selected game
     */
    Game getGame(int index) {
        return games.get(index);
    }

    /**
     * Searches for a game using its identifier.
     *
     * @param id unique game identifier
     * @return matching game or null when not found
     */
    public Game getGame(long id) {

        Game game = null;

        Iterator<Game> gameIterator = games.iterator();

        while (gameIterator.hasNext()) {
            Game currentGame = gameIterator.next();

            if (currentGame.getId() == id) {
                game = currentGame;
                break;
            }
        }

        return game;
    }

    /**
     * Searches for a game using its unique name.
     *
     * @param name unique game name
     * @return matching game or null when not found
     */
    public Game getGame(String name) {

        Game game = null;

        Iterator<Game> gameIterator = games.iterator();

        while (gameIterator.hasNext()) {
            Game currentGame = gameIterator.next();

            if (currentGame.getName().equals(name)) {
                game = currentGame;
                break;
            }
        }

        return game;
    }

    /**
     * Returns the number of active games.
     *
     * @return number of games
     */
    public int getGameCount() {
        return games.size();
    }
}
