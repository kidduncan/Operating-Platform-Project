package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Represents a game in the Draw It or Lose It application.
 * A game inherits its unique identifier and name from Entity
 * and contains one or more teams.
 */
public class Game extends Entity {

    /**
     * Stores the teams participating in this game.
     */
    private List<Team> teams = new ArrayList<Team>();

    /**
     * Constructor.
     *
     * @param id unique game identifier
     * @param name unique game name
     */
    public Game(long id, String name) {
        super(id, name);
    }

    /**
     * Adds a team if the supplied team name is not already being used.
     *
     * The iterator pattern checks each existing team one at a time.
     * If the name already exists, the existing team is returned instead
     * of creating a duplicate.
     *
     * @param name requested team name
     * @return the existing or newly created team
     */
    public Team addTeam(String name) {

        Team team = null;

        Iterator<Team> teamIterator = teams.iterator();

        while (teamIterator.hasNext()) {
            Team currentTeam = teamIterator.next();

            if (currentTeam.getName().equals(name)) {
                team = currentTeam;
                break;
            }
        }

        if (team == null) {
            team = new Team(GameService.getNextTeamId(), name);
            teams.add(team);
        }

        return team;
    }

    /**
     * Returns the team at the specified index.
     *
     * @param index position of the team in the list
     * @return team at the selected index
     */
    public Team getTeam(int index) {
        return teams.get(index);
    }

    /**
     * Returns the number of teams assigned to the game.
     *
     * @return number of teams
     */
    public int getTeamCount() {
        return teams.size();
    }

    /**
     * Returns a formatted description of the game.
     */
    @Override
    public String toString() {
        return "Game [id=" + id + ", name=" + name + "]";
    }
}