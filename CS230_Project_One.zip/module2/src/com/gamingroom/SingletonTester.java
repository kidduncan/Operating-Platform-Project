package com.gamingroom;

/**
 * A class used to test the singleton's behavior.
 *
 * @author coce@snhu.edu
 */
public class SingletonTester {

	/**
	 * Demonstrates that this class accesses the same GameService instance
	 * that was used by ProgramDriver.
	 */
	public void testSingleton() {

		System.out.println("\nAbout to test the singleton...");

		// Obtain the same shared GameService instance.
		GameService service = GameService.getInstance();

		// Print all games already added through ProgramDriver.
		for (int i = 0; i < service.getGameCount(); i++) {
			System.out.println(service.getGame(i));
		}
	}
}
